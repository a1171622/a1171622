# 26016 member check v19: external stair stability set-up (NguyenPC, 12 Nov 2026)

## Input
- **Source:** repo a1171622/a1171622, branch claude/project-thread-tl0ueg, commit 0068af9, file 26016/member-check/v19/26016_check_v19.dat (built by make_v19.py from v17a). v17a and v18 give the same analysis (see RESULTS_v18.md).
- **Folder:** new folder; nothing overwritten. The repo copy is kept as 26016_check_v19_repo.dat.txt.

### Check (a): bracket release literal, FIXED on this PC
- SOFiMSHC manual 5.7.4 (sofimshc_1.pdf p. 5-17) allows only these release literals on SLN FIXA/FIXE: N, VY, VZ, MT, MY, MZ, MB, PP (= NVYVZ) and MM (= MTMYMZ).
- 'PYPZMXMYMZ' is not valid: PY, PZ and MX do not exist.
- I changed SLN 724/725/769/770 to **FIXE 'VYVZMTMYMZ'**. This releases both shears, torsion and both moments at the ring end and keeps N, the vertical force along the vertical bracket axis. I also corrected the header comment; nothing else changed.
- Result check: the bracket shears and moments are 0.07 kN and 0.01 kNm or less in every ULS case, so only N reaches the ring.

### Check (b): BDK buckling length, valid, unchanged
- BDK manual 3.12 MEMB (bdk_1.pdf p. 3-15): SKY / SKZ = "effective buckling length factor" for major / minor axis bending.
- 'SKY 2.0 SKZ 2.0' therefore gives Lcr = 2 L.
- BDK confirms it with warning 169 on the legs: "Elastic critical force N-cr analytically determined, due to explicitly defined buckling length(s)".

## Run
- No SOFiSTiK or IDEA process was running beforehand. One job, run_calculation.
- 1955.7 s (32.6 min; v18 31.3), exit 0, peak RAM about 10.1 GB.
- **0 errors, 278 warnings** (v18 197). The increase comes from:
  - BDKDES 169 (50): the leg Lcr notice above, expected.
  - BDKDES 156 (81, v18 56): more "class 3 assumed".
  - **ASE 537 in each buckling block (new, 1 per block):** "Shear hinges should not be used in an analysis of 3. order TH3 ... beams with shear hinges are calculated only with TH2 effects." This comes from the new VY/VZ releases on the brackets. It does not matter for linear buckling (TH2).
  - AQUA/SOFiMSHC 12149 (+5): long titles of SECT 9 and SLN 791-798 shortened.
- **No** mechanism, singularity, error 197 or unconnected-line messages. SLN 791-798 are connected: they carry small axial forces in every case.

Picture: **26016_v19_external_stair.png / .svg**. It is a plan of the external stair with:
- members coloured by BDK;
- brackets (yellow);
- pinned feet (dark) and leg bases (light);
- red arrows for the horizontal movement of the landing nodes in SLS LC 218, scaled x100.

## Buckling (alpha_cr) and stair modes
| Block | Mode 1 | Modes 2-3 | Mode 20 | v18 mode 1 |
|---|---|---|---|---|
| urs 9201 (PLC 102, 1.35G+1.5Q) | **6.947** | 7.332, 7.589 | 9.583 | 6.881 |
| urs 9202 (PLC 119, G+Q+psiW +X) | **7.357** | 7.639, 7.855 | 10.148 | 7.304 |

- **None of the 40 modes is an external-stair mode.** In every mode the largest movement is at the main structure's raking columns (r 11.6-11.8 m, z 1.74 m) or at one L1 column node.
- Group 62 nodes move at most 3.8 % of the mode's maximum (3.76 of 38.9 in mode 9220). The first stair mode therefore lies above 9.6 (PLC 102) and above 10.1 (PLC 119).
- I made no buckling picture because no stair mode appears.
- If a stair factor is needed, the next step would be more modes (EIGE 60) or a separate stair-only buckling run.

## Landing sway (horizontal resultant, max over the landing nodes)
| Level | Arm | SLS 201-221 | h / sway | ULS 101-154 | h / sway | v18 SLS / ULS |
|---|---|---|---|---|---|---|
| Landing 2 (z 4.43) | right | **20.7 mm** (LC 218, node at S2) | h/214 | **31.2 mm** (LC 119) | h/142 | 2.0 / 3.0 |
| Landing 2 (z 4.43) | left | **19.1 mm** (LC 218, at S4) | h/232 | **28.7 mm** (LC 119) | h/155 | 2.0 / 3.0 |
| Landing 1 (z 2.43) | right | 7.9 mm (LC 202) | h/309 | 12.0 mm (LC 111) | h/202 | 3.9 / 5.8 |
| Landing 1 (z 2.43) | left | 7.1 mm (LC 202) | h/344 | 10.8 mm (LC 111) | h/225 | 3.9 / 5.8 |

- The ring hardly moves (0.6 mm or less at the bracket nodes).
- So landing 2 slides against the L1 ring at the brackets by up to **20.4 mm SLS / 30.6 mm ULS** (S2), 18.9 / 28.3 mm (S4), 12.9 / 19.5 mm (S1) and 11.5 / 17.3 mm (S3).
- The bracket bearing would have to allow this movement, or be detailed to take shear again.
- LC 218 = SLS G+Q+psiW +X down, LC 119 = ULS G+Q+psiW +X down. The sway comes mainly from gravity and live load: the stair now leans on its pinned flight feet.

## Group 62 (external stair): max per member type (v19 | v18)
| Type | n | BDK max | AQB max |
|---|---|---|---|
| Legs (SHS 80x80x6.3, Lcr = 2 L) | 12 | **1.013 SLN 722 LC 122 (NOT PASSED)** \| 0.213 | 0.242 SLN 755 LC 121 \| 0.199 |
| New beams 791-798 (SHS 80x80x6.3, pinned) | 8 | 0.009 (793) | 0.036 (793) |
| Stringers | 8 | 0.210 (758, LC 135) \| 0.230 | 0.400 (758) \| 0.328 |
| Stringer seats (flight 2 foot) | 4 | **0.662 (711, LC 122)** \| 0.277 | 0.672 (711) \| 0.436 |
| Landing beams | 22 | 0.306 (751, LC 121) \| 0.178 | 0.454 (751) \| 0.263 |
| Brackets 724/725/769/770 | 4 | 0.033 \| 0.541 | 0.034 \| 0.852 |
| Treads (5 mm plate, AQB only) | 40 | - | 0.699 (727, flight 1, stress envelope) \| 0.461 |

Top 5 BDK in group 62:
| Member | BDK | LC |
|---|---|---|
| 722 right landing 2 leg outer-low | **1.013** | 122 |
| 767 left landing 2 leg outer-low | 0.993 | 121 |
| 711 right flight 2 inner stringer seat | 0.662 | 122 |
| 756 left flight 2 inner stringer seat | 0.646 | 121 |
| 768 left landing 2 leg outer-high | 0.640 | 119 |

Top 5 AQB in group 62:
| Member | AQB |
|---|---|
| Tread 727 | 0.699 |
| Tread 728 | 0.697 |
| Tread 729 | 0.680 |
| Tread 726 | 0.676 |
| Seat 711 | 0.672 (LC 122) |

Governing leg 722 (4.43 m tall; beams 793/794 at +1.45 and +2.90 frame into it, pinned):
- N -34.8 kN (LC 135), +3.5 kN (LC 133).
- My +1.79 / -0.53 kNm, Mz +0.38 / -0.70 kNm, shears 0.65 kN or less.
- **The leg is almost pure compression.** BDK 1.01 comes from Lcr = 2 x 4.43 = 8.86 m on an SHS 80x80x6.3 (i about 30 mm, slenderness about 290).
- The legs do **not** work as a sway portal: they take under 2 kN of shear. The sideways restraint comes from the pinned flight-1 feet, where the stringers act as raking struts.
- With Lcr = L (a non-sway leg, since the stair is braced by its flights), the leg would be about 0.3. Wing to decide which Lcr is right.
- The new transverse beams 791-798 are almost idle (BDK 0.009 or less), because the legs hardly sway as portals.

## Bracket axial forces (ULS 101-154, N > 0 tension; now no shear)
| Bracket | N max / min v19 | v18 N / max shear |
|---|---|---|
| 724 S1 | +7.0 (LC 125) / **-8.9** (LC 151) | +41.2 / +1.2, V 38.0 |
| 725 S2 | -1.5 / **-17.1** (LC 152) | -0.9 / -17.6, V 30.5 |
| 769 S3 | +5.9 (LC 123) / -8.6 (LC 151) | +40.7 / +1.6, V 30.8 |
| 770 S4 | -1.4 / **-17.4** (LC 152) | -0.9 / -17.9, V 28.7 |

- Shear on every bracket is 0.07 kN or less and moment 0.01 kNm or less.
- The large tension of v18 (about 41-45 kN) has gone. The outer brackets now take +7 / -9 kN, so they still need a small hold-down.

## Ground supports SPT 901-916 (ULS 101-154, pz > 0 = bearing down)
| SPT | Location | px max / min | py max / min | pz max / min | v18 pz min |
|---|---|---|---|---|---|
| 901 | right flight 1 inner foot | +20.8 / -30.4 | +35.1 / -53.0 (LC 111) | +36.9 / **-31.4 uplift (LC 111)** | +0.6 |
| 902 | right flight 1 outer foot | +9.8 / -10.7 | +45.2 / -31.4 | +39.8 / **-20.3** | -2.0 |
| 909 | left flight 1 inner foot | +17.2 / -12.6 | +50.7 (LC 113) / -38.8 | +36.5 / **-26.7 (LC 113)** | +1.1 |
| 910 | left flight 1 outer foot | +23.9 / -30.3 | +23.5 / -38.2 | +38.7 / **-18.6** | -1.5 |
| 903-908, 911-916 | leg bases | 1.0 kN or less | 0.8 kN or less | max down 62.7 (914, LC 135); max uplift 12.8 (911, LC 130) | uplift 15.0 |

- The flight-1 feet are now the stair's lateral supports.
- They take horizontal force up to about 53 kN (901 resultant about 61 kN in LC 111) and **uplift up to 31 kN**. In v18 these feet had almost no uplift.
- The leg bases take almost no horizontal force.

## L1 ring r 12 under the brackets (BDK | AQB, v19 vs v18)
| SLN | v19 BDK | v19 AQB | v18 BDK | v18 AQB | Notes |
|---|---|---|---|---|---|
| 161 (0-20) | 0.497 | 0.478 | 0.388 | 0.346 | My -74.5 at 0 deg (v18 -49.7); Mz 2.2 or less (v18 8.0) |
| 170 (20-40) | 0.554 | 0.523 | 0.514 | 0.424 | My -81.4 at 40 (v18 -66.0); Mz 2.3 or less (v18 7.9) |
| 164 (300-320) | 0.491 | 0.471 | 0.389 | 0.331 | My -73.3 at 320 (v18 -50.0) |
| 165 (280-300) | 0.548 | 0.515 | 0.512 | 0.423 | My -80.2 at 280 (v18 -65.8) |

- The ring loses the uplift from the outer brackets, so vertical bending rises back to v16 levels.
- The in-plan bending and shear from the stair have gone (Mz 2.7 kNm or less, Vy 3 kN or less). Torsion is 0.
- Ring tension at 0 / 320 deg falls to +47 / +57 kN (v18 +67 / +77).

## Overall max per group (v19 | v18)
| Group | BDK | AQB block |
|---|---|---|
| 11 | 0.388 \| 0.391 | 11xxxx 0.384 \| 0.381 |
| 12 | 0.099 \| 0.099 | 12xxxx 0.182 \| 0.184 |
| 13 | 0.269 \| 0.268 | 08xxxx 0.207 \| 0.206 |
| 14 | 0.360 \| 0.360 | |
| 15 L1 radials and ring | 0.645 (263) \| 0.652 | 10xxxx 0.523 \| 0.504 |
| 21 | 0.396 \| 0.388 | |
| 23 | 0.142 \| 0.140 | |
| 24 | 0.294 \| 0.293 | |
| **25 L2** | **1.064 (56, LC 120) \| 1.063** | **14xxxx 1.075 (140020) \| 1.073** |
| 31 | 0.239 \| 0.239 | |
| 35 | 0.617 \| 0.617 | 16xxxx 0.475 \| 0.475 |
| 60 stairs | 0.307 \| 0.300 | 17xxxx 0.623 (tread plate) \| 0.444 |
| 61 posts | 0.112 \| 0.110 | 18xxxx 0.101 \| 0.099 |
| **62 external stair** | **1.013 (leg 722) \| 0.541** | 19xxxx 0.699 (tread) \| 0.852 |

- **Not passed:** 56 1.064, 57 1.015, **722 1.013**, 62 1.006.
- AQB section maxima from the .erg: Section 9 (SHS 80x80x6.3) 0.242, Section 8 (SHS 100x5) 0.101, Section 7 (5 mm plate) 0.699, Total 1.075.
- The internal stair tread plates (group 60) rose 0.444 -> 0.623.
  - Example: tread beam 170105, LC 152, My -0.86 -> -1.32 kNm.
  - The L1 ring and radials now sag more, because the outer brackets no longer lift the ring. This changes the forces in the stair A/B treads.
  - Treads are reported as an AQB stress envelope only.

## Points for Wing to decide
1. **Lateral system:** the stair is held sideways by its pinned flight-1 feet, not by leg portal action.
   - Keep pinned feet: design the feet for H up to about 53 kN and **uplift up to 31 kN**. The legs can then be taken with Lcr = L (BDK about 0.3), and the transverse beams are not needed for sway.
   - Or let the feet slide (v20): the legs and new beams then have to work as portals, and sway will grow.
2. **Ring brackets:** the landing slides against the ring up to 20 mm SLS / 31 mm ULS. The bearing must allow it (slotted / PTFE), and the outer brackets still see up to 7 kN uplift.
3. **Leg 722 / 767:** 1.01 / 0.99 with the conservative Lcr = 2 L.
